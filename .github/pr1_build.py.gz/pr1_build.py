#!/usr/bin/env python3
"""Build the clean two-commit PR 1 stack from the pinned PR 0 head."""

from __future__ import annotations

import ast
import json
import re
import sys
from pathlib import Path

BASE_SHA = "79ef9f89d3afca243f0c9a983389db92cf683a44"
ISSUE = 96692
PR0 = 97102
COMMANDS_PATH = Path("hermes_cli/commands.py")
COMPLETION_PATH = Path("hermes_cli/command_completion.py")
CHARACTERIZATION_PATH = Path(
    "tests/conformance/test_command_plane_characterization.py"
)
SCHEMA_TEST_PATH = Path("tests/hermes_cli/test_command_schema.py")
MANIFEST_PATH = Path("docs/architecture/command-plane/pr1-schema.json")

AUTOCOMPLETE_MARKER = (
    "# ---------------------------------------------------------------------------\n"
    "# Autocomplete\n"
    "# ---------------------------------------------------------------------------\n"
)
COMMANDDEF_MARKER = (
    "# ---------------------------------------------------------------------------\n"
    "# CommandDef dataclass\n"
    "# ---------------------------------------------------------------------------\n"
)
PROMPT_TOOLKIT_MARKER = "# prompt_toolkit is an optional CLI dependency"
COMMAND_COMPLETION_IMPORT = '''from hermes_cli.command_completion import (
    AutoSuggest,
    Completion,
    Completer,
    SlashCommandAutoSuggest,
    SlashCommandCompleter,
    Suggestion,
    _file_size_label,
)
'''

COMPLETION_HEADER = '''"""Prompt-toolkit completion and inline suggestions for Hermes slash commands.

The semantic registry remains in :mod:`hermes_cli.commands`. Access to its
derived command maps is deliberately lazy so this bounded presentation module
can be imported independently without becoming a second registry owner or
creating an import cycle.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import time
from collections.abc import Callable, Mapping
from typing import Any

try:
    from prompt_toolkit.auto_suggest import AutoSuggest, Suggestion
    from prompt_toolkit.completion import Completer, Completion
except ImportError:  # pragma: no cover
    AutoSuggest = object  # type: ignore[assignment,misc]
    Completer = object  # type: ignore[assignment,misc]
    Suggestion = None  # type: ignore[assignment]
    Completion = None  # type: ignore[assignment]


def _commands() -> dict[str, str]:
    """Return the current compatibility command projection lazily."""
    from hermes_cli.commands import COMMANDS

    return COMMANDS


def _subcommands() -> dict[str, list[str]]:
    """Return the current compatibility subcommand projection lazily."""
    from hermes_cli.commands import SUBCOMMANDS

    return SUBCOMMANDS


def _personalities() -> dict[str, Any]:
    """Return the registry owner's mtime-cached personality projection."""
    from hermes_cli.commands import _personalities_from_cli_config

    return _personalities_from_cli_config()


# ---------------------------------------------------------------------------
# Autocomplete
# ---------------------------------------------------------------------------

'''

SCHEMA_CONSTANTS = '''COMMAND_SPEC_SCHEMA_VERSION = 1
"""Version of the JSON-safe core command metadata projection."""

_COMMAND_ID_RE = re.compile(r"^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$")
_COMMAND_TOKEN_RE = re.compile(r"^[a-z0-9][a-z0-9_-]*$")


'''

DESCRIPTION_KEY_PROPERTY = '''
    @property
    def description_key(self) -> str:
        """Stable localization key derived from semantic identity, not spelling."""
        if not self.command_id:
            raise ValueError("command_id is required before projecting command metadata")
        return f"commands.{self.command_id}.description"
'''

COMMAND_SPEC_FUNCTION = '''


def command_spec_v1(cmd: CommandDef) -> dict[str, Any]:
    """Return the JSON-safe PR 1 metadata slice of ``CommandSpec``.

    This projection owns stable identity and metadata already carried by the
    current core registry. It intentionally does not claim execution, policy,
    context assembly, catalog revision, or result semantics that migrate in
    later slices of #96692.
    """
    validate_command_registry([cmd])
    return {
        "schema_version": COMMAND_SPEC_SCHEMA_VERSION,
        "command_id": cmd.command_id,
        "name": cmd.name,
        "aliases": list(cmd.aliases),
        "description_key": cmd.description_key,
        "description_fallback": cmd.description,
        "category": cmd.category,
        "argument_schema": {
            "kind": "legacy",
            "mode": infer_argument_mode(cmd),
            "hint": cmd.args_hint,
            "subcommands": list(cmd.subcommands),
        },
        "availability": {
            "cli_only": cmd.cli_only,
            "gateway_only": cmd.gateway_only,
            "gateway_config_gate": cmd.gateway_config_gate,
        },
        "visibility": {
            "desktop": cmd.desktop,
        },
        "busy_policy": cmd.busy_policy,
    }
'''

VALIDATION_FUNCTIONS = '''def validate_command_registry(
    commands: list[CommandDef] | tuple[CommandDef, ...],
) -> None:
    """Fail closed on invalid or colliding core command identities and tokens."""
    command_ids: dict[str, str] = {}
    tokens: dict[str, str] = {}

    for cmd in commands:
        if not _COMMAND_ID_RE.fullmatch(cmd.command_id):
            raise ValueError(
                f"invalid command_id {cmd.command_id!r} for /{cmd.name}; "
                "expected a stable lowercase dotted identifier"
            )
        previous_name = command_ids.get(cmd.command_id)
        if previous_name is not None:
            raise ValueError(
                f"duplicate command_id {cmd.command_id!r}: "
                f"/{previous_name} and /{cmd.name}"
            )
        command_ids[cmd.command_id] = cmd.name

        for kind, entered_name in (
            ("name", cmd.name),
            *(("alias", alias) for alias in cmd.aliases),
        ):
            token = entered_name.casefold()
            if entered_name != token or not _COMMAND_TOKEN_RE.fullmatch(token):
                raise ValueError(
                    f"invalid command {kind} {entered_name!r} for "
                    f"{cmd.command_id!r}"
                )
            previous_owner = tokens.get(token)
            if previous_owner is not None:
                raise ValueError(
                    f"duplicate command token {entered_name!r}: "
                    f"{previous_owner} and {cmd.command_id}:{kind}"
                )
            tokens[token] = f"{cmd.command_id}:{kind}"


def _build_command_lookup(
    commands: list[CommandDef] | tuple[CommandDef, ...] | None = None,
) -> dict[str, CommandDef]:
    """Map every validated name and alias to exactly one ``CommandDef``."""
    definitions = COMMAND_REGISTRY if commands is None else commands
    validate_command_registry(definitions)

    lookup: dict[str, CommandDef] = {}
    for cmd in definitions:
        lookup[cmd.name] = cmd
        for alias in cmd.aliases:
            lookup[alias] = cmd
    return lookup
'''


def _read(root: Path, relative: Path) -> str:
    return (root / relative).read_text(encoding="utf-8")


def _write(root: Path, relative: Path, content: str) -> None:
    path = root / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def _replace_once(source: str, old: str, new: str, *, label: str) -> str:
    count = source.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected one anchor, found {count}")
    return source.replace(old, new, 1)


def _node_bounds(source: str, node: ast.AST) -> tuple[int, int]:
    """Translate AST UTF-8 byte columns into Python character offsets."""
    lines = source.splitlines(keepends=True)
    starts: list[int] = []
    cursor = 0
    for line in lines:
        starts.append(cursor)
        cursor += len(line)

    def char_column(line: str, byte_column: int) -> int:
        raw = line.encode("utf-8")
        return len(raw[:byte_column].decode("utf-8"))

    assert hasattr(node, "lineno")
    assert hasattr(node, "end_lineno")
    start_line = int(node.lineno) - 1
    end_line = int(node.end_lineno) - 1
    start = starts[start_line] + char_column(lines[start_line], int(node.col_offset))
    end = starts[end_line] + char_column(lines[end_line], int(node.end_col_offset))
    return start, end


def _function_node(source: str, name: str) -> ast.FunctionDef:
    tree = ast.parse(source)
    matches = [
        node
        for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == name
    ]
    if len(matches) != 1:
        raise RuntimeError(f"expected one function {name!r}, found {len(matches)}")
    return matches[0]


def _replace_function(source: str, name: str, replacement: str) -> str:
    node = _function_node(source, name)
    start, end = _node_bounds(source, node)
    return source[:start] + replacement.rstrip() + source[end:]


def _insert_after_function(source: str, name: str, addition: str) -> str:
    node = _function_node(source, name)
    _, end = _node_bounds(source, node)
    return source[:end] + addition + source[end:]


def _loaded_names(source: str) -> set[str]:
    tree = ast.parse(source)
    return {
        node.id
        for node in ast.walk(tree)
        if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load)
    }


def extract_completion_module(root: Path) -> None:
    source = _read(root, COMMANDS_PATH)
    if AUTOCOMPLETE_MARKER not in source:
        raise RuntimeError("autocomplete boundary not found")
    if (root / COMPLETION_PATH).exists():
        raise RuntimeError(f"{COMPLETION_PATH} already exists")

    prefix, tail = source.split(AUTOCOMPLETE_MARKER, 1)
    tail = tail.lstrip("\n")
    if not tail.startswith("class SlashCommandCompleter"):
        raise RuntimeError("unexpected autocomplete tail")

    tail = re.sub(r"\bCOMMANDS\b", "_commands()", tail)
    tail = re.sub(r"\bSUBCOMMANDS\b", "_subcommands()", tail)
    tail = tail.replace("_personalities_from_cli_config()", "_personalities()")
    completion_source = COMPLETION_HEADER + tail
    ast.parse(completion_source)

    prompt_start = prefix.index(PROMPT_TOOLKIT_MARKER)
    prompt_end = prefix.index(COMMANDDEF_MARKER, prompt_start)
    prefix = prefix[:prompt_start] + prefix[prompt_end:]

    local_import_anchor = "from hermes_constants import INDICATOR_STYLES\n"
    prefix = _replace_once(
        prefix,
        local_import_anchor,
        local_import_anchor + "\n" + COMMAND_COMPLETION_IMPORT,
        label="completion import",
    )

    # Move imports used only by the extracted presentation module.
    loaded = _loaded_names(prefix)
    for module in ("os", "shutil", "subprocess", "time"):
        if module not in loaded:
            prefix = prefix.replace(f"import {module}\n", "")
    loaded = _loaded_names(prefix)
    if "Callable" not in loaded:
        prefix = prefix.replace(
            "from collections.abc import Callable, Mapping\n",
            "from collections.abc import Mapping\n",
        )

    prefix = prefix.rstrip() + "\n"
    ast.parse(prefix)

    _write(root, COMMANDS_PATH, prefix)
    _write(root, COMPLETION_PATH, completion_source)

    if len(prefix.splitlines()) >= 2000:
        raise RuntimeError("commands.py extraction did not restore the size boundary")
    if len(completion_source.splitlines()) >= 2000:
        raise RuntimeError("command_completion.py exceeds the size boundary")


def _registry_calls(source: str) -> list[tuple[ast.Call, str, str]]:
    tree = ast.parse(source)
    registry_value: ast.expr | None = None
    for node in tree.body:
        if (
            isinstance(node, ast.AnnAssign)
            and isinstance(node.target, ast.Name)
            and node.target.id == "COMMAND_REGISTRY"
        ):
            registry_value = node.value
            break
    if not isinstance(registry_value, (ast.List, ast.Tuple)):
        raise RuntimeError("COMMAND_REGISTRY literal not found")

    calls: list[tuple[ast.Call, str, str]] = []
    for element in registry_value.elts:
        if not (
            isinstance(element, ast.Call)
            and isinstance(element.func, ast.Name)
            and element.func.id == "CommandDef"
        ):
            raise RuntimeError("COMMAND_REGISTRY contains a non-CommandDef entry")
        if len(element.args) < 3:
            raise RuntimeError("CommandDef entry has fewer than three positional fields")
        name_node, _, category_node = element.args[:3]
        if not (
            isinstance(name_node, ast.Constant)
            and isinstance(name_node.value, str)
            and isinstance(category_node, ast.Constant)
            and isinstance(category_node.value, str)
        ):
            raise RuntimeError("CommandDef name/category must be string literals in PR 1")
        if any(keyword.arg == "command_id" for keyword in element.keywords):
            raise RuntimeError(f"/{name_node.value} already has command_id")
        calls.append((element, name_node.value, category_node.value))
    return calls


def _identity_namespace(category: str) -> str:
    namespace = re.sub(r"[^a-z0-9]+", "-", category.casefold()).strip("-")
    if not namespace:
        raise RuntimeError(f"cannot derive identity namespace from {category!r}")
    return namespace


def _add_explicit_command_ids(source: str) -> tuple[str, dict[str, str]]:
    calls = _registry_calls(source)
    edits: list[tuple[int, int, str]] = []
    command_ids: dict[str, str] = {}

    for call, name, category in calls:
        command_id = f"{_identity_namespace(category)}.{name}"
        if name in command_ids:
            raise RuntimeError(f"duplicate canonical name {name!r}")
        if command_id in command_ids.values():
            raise RuntimeError(f"duplicate generated command_id {command_id!r}")
        command_ids[name] = command_id

        start, end = _node_bounds(source, call)
        segment = source[start:end]
        close = segment.rfind(")")
        if close < 0:
            raise RuntimeError(f"missing closing parenthesis for /{name}")
        before = segment[:close]
        stripped = before.rstrip()
        whitespace = before[len(stripped):]
        comma = "" if stripped.endswith(",") else ","
        replacement = (
            stripped
            + comma
            + f' command_id="{command_id}"'
            + whitespace
            + segment[close:]
        )
        edits.append((start, end, replacement))

    for start, end, replacement in sorted(edits, reverse=True):
        source = source[:start] + replacement + source[end:]

    ast.parse(source)
    return source, command_ids


def _manifest(command_ids: dict[str, str], inventory: dict) -> dict:
    implemented = ["command_id", "description_key", "availability", "visibility"]
    missing = list(inventory["missing_command_plane_fields"])
    return {
        "schema_version": 1,
        "issue": ISSUE,
        "scope": "PR 1 stable identity and minimum versioned core metadata",
        "stack": {
            "pr": PR0,
            "head": BASE_SHA,
            "merge_order": [PR0, "PR 1"],
        },
        "command_spec_schema_version": 1,
        "identity_grammar": "^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$",
        "added_commanddef_fields": ["command_id"],
        "implemented_command_plane_fields": implemented,
        "deferred_command_plane_fields": [
            field for field in missing if field not in implemented
        ],
        "deliberately_deferred": [
            "context-scoped contributor assembly",
            "catalog_revision",
            "execution_owner and handler_id",
            "authorization, confirmation, mutation, live-session, retry, and idempotency policy",
            "typed CommandInvocation and CommandResult",
            "client and platform migration",
        ],
        "planned_files": [
            "hermes_cli/commands.py",
            "hermes_cli/command_completion.py",
            "docs/architecture/command-plane/pr1-schema.json",
            "tests/conformance/test_command_plane_characterization.py",
            "tests/hermes_cli/test_command_schema.py",
        ],
        "command_ids": command_ids,
    }


def _update_characterization(root: Path) -> None:
    source = _read(root, CHARACTERIZATION_PATH)
    source = _replace_once(
        source,
        'INVENTORY_PATH = ROOT / "docs/architecture/command-plane/pr0-inventory.json"\n',
        'INVENTORY_PATH = ROOT / "docs/architecture/command-plane/pr0-inventory.json"\n'
        'PR1_SCHEMA_PATH = ROOT / "docs/architecture/command-plane/pr1-schema.json"\n',
        label="PR1 schema path",
    )
    inventory_helper = '''def _inventory() -> dict:
    return json.loads(INVENTORY_PATH.read_text(encoding="utf-8"))
'''
    source = _replace_once(
        source,
        inventory_helper,
        inventory_helper
        + '''


def _pr1_schema() -> dict:
    return json.loads(PR1_SCHEMA_PATH.read_text(encoding="utf-8"))
''',
        label="PR1 schema loader",
    )
    replacement = '''def test_inventory_matches_current_commanddef_boundary() -> None:
    inventory = _inventory()
    pr1_schema = _pr1_schema()
    current_fields = {field.name for field in fields(CommandDef)}

    expected_fields = set(inventory["current_commanddef_fields"])
    expected_fields.update(pr1_schema["added_commanddef_fields"])
    assert current_fields == expected_fields

    implemented = set(pr1_schema["implemented_command_plane_fields"])
    remaining = set(inventory["missing_command_plane_fields"]) - implemented
    assert current_fields.isdisjoint(remaining)
    assert {command.busy_policy for command in COMMAND_REGISTRY} <= VALID_BUSY_POLICIES
'''
    source = _replace_function(
        source, "test_inventory_matches_current_commanddef_boundary", replacement
    )
    ast.parse(source)
    _write(root, CHARACTERIZATION_PATH, source)


def _schema_tests() -> str:
    return '''"""PR 1 invariants for stable core slash-command identity and metadata."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from hermes_cli import command_completion
from hermes_cli.commands import (
    COMMAND_REGISTRY,
    COMMAND_SPEC_SCHEMA_VERSION,
    SlashCommandAutoSuggest,
    SlashCommandCompleter,
    CommandDef,
    _file_size_label,
    command_spec_v1,
    resolve_command,
    validate_command_registry,
)

ROOT = Path(__file__).resolve().parents[2]
MANIFEST_PATH = ROOT / "docs/architecture/command-plane/pr1-schema.json"
SPEC_KEYS = {
    "schema_version",
    "command_id",
    "name",
    "aliases",
    "description_key",
    "description_fallback",
    "category",
    "argument_schema",
    "availability",
    "visibility",
    "busy_policy",
}
DEFERRED_KEYS = {
    "catalog_revision",
    "execution_owner",
    "handler_id",
    "live_session_requirement",
    "authorization_policy",
    "confirmation_policy",
    "mutation_scope",
    "idempotency_policy",
    "retry_policy",
    "result_capabilities",
}


def _manifest() -> dict:
    return json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))


def _definition(
    name: str,
    command_id: str,
    *,
    aliases: tuple[str, ...] = (),
) -> CommandDef:
    return CommandDef(
        name,
        f"Run /{name}",
        "Test",
        aliases=aliases,
        command_id=command_id,
    )


def test_manifest_pins_every_explicit_core_identity() -> None:
    manifest = _manifest()
    expected = manifest["command_ids"]

    assert manifest["schema_version"] == 1
    assert manifest["issue"] == 96692
    assert manifest["stack"]["pr"] == 97102
    assert manifest["stack"]["head"] == "79ef9f89d3afca243f0c9a983389db92cf683a44"
    assert set(expected) == {command.name for command in COMMAND_REGISTRY}

    for command in COMMAND_REGISTRY:
        assert command.command_id == expected[command.name]
        assert command.description_key == f"commands.{command.command_id}.description"


def test_names_and_aliases_preserve_one_semantic_identity() -> None:
    for command in COMMAND_REGISTRY:
        for entered_name in (command.name, *command.aliases):
            assert resolve_command(entered_name) is command
            assert resolve_command(f"/{entered_name}") is command
            assert resolve_command(entered_name.upper()) is command
            assert resolve_command(entered_name).command_id == command.command_id


def test_command_spec_v1_is_exact_and_json_safe() -> None:
    for command in COMMAND_REGISTRY:
        payload = command_spec_v1(command)

        assert set(payload) == SPEC_KEYS
        assert payload["schema_version"] == COMMAND_SPEC_SCHEMA_VERSION == 1
        assert payload["command_id"] == command.command_id
        assert payload["description_key"] == command.description_key
        assert payload["description_fallback"] == command.description
        assert set(payload["argument_schema"]) == {
            "kind",
            "mode",
            "hint",
            "subcommands",
        }
        assert payload["argument_schema"]["kind"] == "legacy"
        assert set(payload["availability"]) == {
            "cli_only",
            "gateway_only",
            "gateway_config_gate",
        }
        assert set(payload["visibility"]) == {"desktop"}
        assert not (set(payload) & DEFERRED_KEYS)
        json.dumps(payload, sort_keys=True)


@pytest.mark.parametrize(
    "definitions, match",
    [
        (
            [_definition("one", "test.same"), _definition("two", "test.same")],
            "duplicate command_id",
        ),
        (
            [
                _definition("one", "test.one", aliases=("two",)),
                _definition("two", "test.two"),
            ],
            "duplicate command token",
        ),
        (
            [_definition("one", "test.one", aliases=("dup", "dup"))],
            "duplicate command token",
        ),
        (
            [_definition("one", "Not Stable")],
            "invalid command_id",
        ),
        (
            [_definition("One", "test.one")],
            "invalid command name",
        ),
    ],
)
def test_registry_validation_fails_closed(
    definitions: list[CommandDef],
    match: str,
) -> None:
    with pytest.raises(ValueError, match=match):
        validate_command_registry(definitions)


def test_completion_extraction_preserves_compatibility_exports() -> None:
    assert SlashCommandCompleter is command_completion.SlashCommandCompleter
    assert SlashCommandAutoSuggest is command_completion.SlashCommandAutoSuggest
    assert _file_size_label is command_completion._file_size_label


def test_owning_modules_are_bounded() -> None:
    for relative in (
        "hermes_cli/commands.py",
        "hermes_cli/command_completion.py",
    ):
        line_count = len((ROOT / relative).read_text(encoding="utf-8").splitlines())
        assert line_count < 2000, f"{relative} has {line_count} lines"
'''


def add_stable_identity_schema(root: Path) -> None:
    source = _read(root, COMMANDS_PATH)

    category_line = (
        '    category: str                      # "Session", "Configuration", etc.\n'
    )
    source = _replace_once(
        source,
        category_line,
        category_line
        + '    command_id: str = field(default="", kw_only=True)  # stable semantic identity\n',
        label="CommandDef.command_id",
    )

    desktop_line = "    desktop: str | None = None\n"
    source = _replace_once(
        source,
        desktop_line,
        desktop_line + DESCRIPTION_KEY_PROPERTY,
        label="CommandDef.description_key",
    )

    busy_anchor = "# Valid values for CommandDef.busy_policy (see field docs above).\n"
    source = _replace_once(
        source,
        busy_anchor,
        SCHEMA_CONSTANTS + busy_anchor,
        label="schema constants",
    )

    source, command_ids = _add_explicit_command_ids(source)

    source = _insert_after_function(
        source, "command_desktop_meta", COMMAND_SPEC_FUNCTION
    )
    source = _replace_function(source, "_build_command_lookup", VALIDATION_FUNCTIONS)
    ast.parse(source)
    _write(root, COMMANDS_PATH, source)

    inventory = json.loads(
        _read(root, Path("docs/architecture/command-plane/pr0-inventory.json"))
    )
    manifest = _manifest(command_ids, inventory)
    _write(
        root,
        MANIFEST_PATH,
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
    )
    _update_characterization(root)
    _write(root, SCHEMA_TEST_PATH, _schema_tests())

    if len(source.splitlines()) >= 2000:
        raise RuntimeError("commands.py exceeds the size boundary after PR 1")


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: pr1_build.py <extract|schema> <worktree>")
    stage, worktree = sys.argv[1], Path(sys.argv[2]).resolve()
    if not (worktree / ".git").exists():
        raise SystemExit(f"not a git worktree: {worktree}")

    if stage == "extract":
        extract_completion_module(worktree)
    elif stage == "schema":
        add_stable_identity_schema(worktree)
    else:
        raise SystemExit(f"unknown stage: {stage}")


if __name__ == "__main__":
    main()
